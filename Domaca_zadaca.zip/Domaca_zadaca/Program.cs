﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domaca_zadaca
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Temperatura ledišta vode je 0°C");
            Console.WriteLine("Temperatura vrelišta vode je 100°C");
            Console.ReadKey();
        }
    }
}
